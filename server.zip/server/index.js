const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const path = require('path');
require('dotenv').config();

const { sequelize } = require('./models/index');
const authRoutes = require('./routes/auth');
const courseRoutes = require('./routes/courses');
const productRoutes = require('./routes/products');
const adminRoutes = require('./routes/admin');
const uploadRoutes = require('./routes/upload');

const app = express();

// ── CORS ─────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.CLIENT_URL,
  credentials: true,
}));
app.use(express.json());
app.use(cookieParser());

// ── Static: uploaded files (available at /vinutha/uploads/*) ─────────
app.use('/vinutha/uploads', express.static(path.join(__dirname, 'uploads')));

// ── API routes (all under /vinutha/api) ──────────────────────────────
app.use('/vinutha/api/auth', authRoutes);
app.use('/vinutha/api/courses', courseRoutes);
app.use('/vinutha/api/products', productRoutes);
app.use('/vinutha/api/admin', adminRoutes);
app.use('/vinutha/api/upload', uploadRoutes);
app.get('/vinutha/api/health', (req, res) => res.json({ status: 'OK' }));

// ── Serve React build (production) ───────────────────────────────────
// The built files are in client/dist; assets are at /vinutha/assets/*
const distDir = path.join(__dirname, '../client/dist');
app.use('/vinutha', express.static(distDir));

// Catch-all: serve React's index.html for client-side routes under /vinutha
// Note: Express 5 requires named wildcards (*path instead of *)
app.get('/vinutha/*path', (req, res) => {
  res.sendFile(path.join(distDir, 'index.html'));
});

// Root redirect → /vinutha/
app.get('/', (req, res) => res.redirect('/vinutha/'));

// ── Start server ──────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;

sequelize.sync({ alter: true }).then(() => {
  console.log('✅ MySQL tables synced');
  app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}/vinutha/`);
  });
}).catch((err) => {
  console.error('❌ DB sync error:', err.message);
  process.exit(1);
});
